G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-02-24T18:56:15-05:00*
G04 #@! TF.ProjectId,prac3,70726163-332e-46b6-9963-61645f706362,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-02-24 18:56:15*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.500000X1.050000*%
%ADD11O,1.500000X1.050000*%
%ADD12RoundRect,0.250000X0.450000X-0.262500X0.450000X0.262500X-0.450000X0.262500X-0.450000X-0.262500X0*%
%ADD13R,1.700000X1.700000*%
%ADD14C,1.700000*%
%ADD15RoundRect,0.243750X0.243750X0.456250X-0.243750X0.456250X-0.243750X-0.456250X0.243750X-0.456250X0*%
%ADD16R,2.000000X2.000000*%
%ADD17C,2.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,U1*
X151860000Y-95770000D03*
D11*
X151860000Y-94500000D03*
X151860000Y-93230000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X144360000Y-101182500D03*
X144360000Y-99357500D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J2*
X134500000Y-93920000D03*
D14*
X134500000Y-96460000D03*
X134500000Y-99000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X134500000Y-82960000D03*
D14*
X134500000Y-85500000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,D1*
X152437500Y-101500000D03*
X150562500Y-101500000D03*
G04 #@! TD*
D16*
G04 #@! TO.C,BZ1*
X148000000Y-79200000D03*
D17*
X148000000Y-86800000D03*
G04 #@! TD*
M02*
