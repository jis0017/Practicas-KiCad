G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-02-21T23:55:31-05:00*
G04 #@! TF.ProjectId,prac2,70726163-322e-46b6-9963-61645f706362,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-02-21 23:55:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12C,1.500000*%
%ADD13RoundRect,0.243750X-0.243750X-0.456250X0.243750X-0.456250X0.243750X0.456250X-0.243750X0.456250X0*%
%ADD14RoundRect,0.250000X-0.262500X-0.450000X0.262500X-0.450000X0.262500X0.450000X-0.262500X0.450000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X107000000Y-103000000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X107000000Y-92500000D03*
D11*
X107000000Y-95040000D03*
X107000000Y-97580000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X118000000Y-93300000D03*
X118000000Y-96700000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,D1*
X116562500Y-102500000D03*
X118437500Y-102500000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,R3*
X111087500Y-95500000D03*
X112912500Y-95500000D03*
G04 #@! TD*
G04 #@! TO.C,R2*
X111087500Y-102500000D03*
X112912500Y-102500000D03*
G04 #@! TD*
M02*
